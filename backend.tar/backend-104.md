Git
 is a free and open source distributed version control system designed to handle everything from small to very large projects with speed and efficiency.
Visit the following resources to learn more:
Version control/source control systems allow developers to track and control changes to code over time. These services often include the ability to make atomic revisions to code, branch/fork off of specific points, and to compare versions of code. They are useful in determining the who, what, when, and why code changes were made.
Visit the following resources to learn more:
Git
 is a free and open source distributed version control system designed to handle everything from small to very large projects with speed and efficiency.
Visit the following resources to learn more:
