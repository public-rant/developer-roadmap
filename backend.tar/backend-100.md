Web hosting is an online service that allows you to publish your website files onto the internet. So, anyone who has access to the internet has access to your website.
Visit the following resources to learn more:
The Domain Name System (DNS) is the phonebook of the Internet. Humans access information online through domain names, like nytimes.com or espn.com. Web browsers interact through Internet Protocol (IP) addresses. DNS translates domain names to IP addresses so browsers can load Internet resources.
Visit the following resources to learn more:
A web browser is a software application that enables a user to access and display web pages or other online content through its graphical user interface.
Visit the following resources to learn more:
A domain name is a unique, easy-to-remember address used to access websites, such as ‘google.com’, and ‘facebook.com’. Users can connect to websites using domain names thanks to the DNS system.
Visit the following resources to learn more:
The Internet is a global network of computers connected to each other which communicate through a standardized set of protocols.
Visit the following resources to learn more:
HTTP is the 
TCP/IP
 based application layer communication protocol which standardizes how the client and server communicate with each other. It defines how the content is requested and transmitted across the internet.
Visit the following resources to learn more:
The Internet is a global network of computers connected to each other which communicate through a standardized set of protocols.
Visit the following resources to learn more:
In GraphQL, the backend refers to the server-side of the application, where the data is stored and processed.
When using GraphQL on the backend, developers can create a GraphQL server that handles the incoming GraphQL queries and mutations from the frontend. This can be implemented using a GraphQL library or framework, such as Apollo Server, Express-GraphQL, or GraphQL-Java.
The GraphQL server is responsible for handling the incoming queries and mutations, validating them against a schema, and executing them by fetching data from the database or other data sources. The server then returns the requested data to the client in a predictable format, as defined by the schema.
Learn more from the following links:
